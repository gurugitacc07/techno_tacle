<?php
namespace App\Http\Controllers;
use App\Models\Order;
use App\Models\Customer;
use App\Models\Product;
use Illuminate\Http\Request;

class OrderController extends Controller
{
    public function index()
    {
        $orders = Order::leftjoin('customers','customers.customer_id','=','orders.customer_id')
        ->leftjoin('products','products.product_id','=','orders.product_id')
        ->get();
        return view('order.index', compact('orders'));
    }

    public function create()
    {
        // Retrieve necessary data for dropdowns or inputs, if required
        $customers = Customer::get();
        $products = Product::get(); 
        return view('order.add')->with(['customers'=>$customers,'products'=>$products]);
    }

    public function store(Request $request)
    {
        // Validate and store the submitted order data
        $validatedData = $request->validate([
            'customer_id' => 'required|exists:customers,customer_id',
            'product_id' => 'required|exists:products,product_id',
            'quantity' => 'required|integer|min:1',
        ]);

        // Order::create($validatedData);
        $total_amount = (float)$request->quantity*(float)$request->price;
        $order = new Order();

        $order->order_date = $request->order_date;
        $order->customer_id = $request->customer_id;
        $order->product_id = $request->product_id;
        $order->quantity = $request->quantity;
        $order->total_amount = $total_amount;
        $order->save();

        return redirect()->route('orders.index')->with('success', 'Order created successfully.');
    }

    public function show(Order $order)
    {
        // Retrieve and show the details of a specific order
        // $order->load('customer', 'product');
        // return view('order.show', compact('order'));
    }

    public function edit(Request $request,$id)
    {
        // dd($id);

        $customers = Customer::get();
        $products = Product::get(); 
        $order = Order::leftjoin('customers','customers.customer_id','=','orders.customer_id')
        ->leftjoin('products','products.product_id','=','orders.product_id')->where('orders.order_id',$id)->first();
        return view('order.edit', compact('order','customers','products'));
    }

    public function update(Request $request,$id)
    {
        // Validate and update the submitted order data
        $validatedData = $request->validate([
            'customer_id' => 'required|exists:customers,customer_id',
            'product_id' => 'required|exists:products,product_id',
            'quantity' => 'required|integer|min:1',
        ]);
        $total_amount = (float)$request->quantity*(float)$request->price;
        $order_update = Order::where('order_id',$id)->update([
            'order_date'=>$request->order_date,
            'customer_id'=>$request->customer_id,
            'product_id'=>$request->product_id,
            'quantity'=>$request->quantity,
            'total_amount'=>$total_amount,
        ]);

        return redirect()->route('orders.index')->with('success', 'Order updated successfully.');
    }

    public function destroy(Request $request,$id)
    {
        // Delete a specific order
        Order::where('order_id',$id)->delete();

        return redirect()->route('orders.index')->with('success', 'Order deleted successfully.');
    }
}