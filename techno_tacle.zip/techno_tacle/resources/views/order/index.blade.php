@extends('layouts.asidebar')
 
@section('content')
    <div class="row">
        <div class="col-lg-12" style="display: flex; justify-content: space-between;">
            <div class="pull-left">
                <h2>Orders</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="{{ route('orders.create') }}"> Create New Order</a>
            </div>
        </div>
    </div>
   
    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif
   
    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Order Date</th>
            <th>Customer Name</th>
            <th>Address</th>
            <th>Total Amount</th>
            <th width="280px">Action</th>
        </tr>
        <?php $i = 0; ?>
        @foreach ($orders as $order)
        <tr>
            <td>{{ ++$i }}</td>
            <td>{{ $order->order_date}}</td>
            <td>{{ $order->customer_name }}</td>
            <td>{{ $order->address }}</td>
            <td>{{ $order->total_amount }}</td>
            <td>
                <form action="{{ route('orders.destroy',$order->order_id) }}" method="POST">
                    <a class="btn btn-primary" href="{{ route('orders.edit',$order->order_id) }}">Edit</a>
   
                    @csrf
                    @method('DELETE')
      
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </td>
        </tr>
        @endforeach
    </table>
  
      
@endsection