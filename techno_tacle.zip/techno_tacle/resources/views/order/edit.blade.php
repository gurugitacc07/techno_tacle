@extends('layouts.asidebar')
   
@section('content')
    <div class="row">
        <div class="col-lg-12" style="display: flex; justify-content: space-between;">
            <div class="pull-left">
                <h2>Edit Order</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="{{ route('orders.index') }}"> Back</a>
            </div>
        </div>
    </div>
   
    @if ($errors->any())
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif
  
    <form action="{{ route('orders.update',$order->order_id) }}" method="POST">
        @csrf
        @method('PUT')
   
         <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Order Date:</strong>
                    <input type="date" name="order_date" id="order_date" class="form-control" value="{{ date('Y-m-d', strtotime($order->order_date)) }}" required>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Customer Name:</strong>
                    <select class="form-select" aria-label="multiple select example" name="customer_id" id="customer_id">
                        <option selected>Open this select menu</option>
                        @foreach($customers as $customer)
                        <option value="{{$customer->customer_id}}" @if($order->customer_id == $customer->customer_id) selected @endif>{{$customer->customer_name}}</option>
                        @endforeach
                    </select>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Product Name:</strong>
                    <select class="form-select" aria-label="multiple select example" name="product_id" id="product_id">
                        <option selected>Open this select menu</option>
                        @foreach($products as $product)
                        <option value="{{$product->product_id}}" @if($order->product_id == $product->product_id) selected @endif>{{$product ->product_name}}</option>
                        @endforeach
                    </select>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Quantity:</strong>
                    <input type="number" name="quantity" id="quantity" class="form-control" value="{{$order->quantity}}" required>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Price:</strong>
                    <input type="number" name="price" id="price" class="form-control" value="{{$order->total_amount/$order->quantity}}" required>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12" style="margin-top: 1%;">
              <button type="submit" class="btn btn-primary" style="float: right;">Submit</button>
            </div>
        </div>
   
    </form>
@endsection